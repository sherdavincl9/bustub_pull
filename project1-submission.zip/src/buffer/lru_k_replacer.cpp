//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  bool victim_found = false;
  // try to evict the earliest one from hist list (frames that haven't reach k-hits, +inf distance)
  if (!hist_list_.empty()) {
    // find first evictable frame
    for (auto rit = hist_list_.rbegin(); rit != hist_list_.rend(); ++rit) {
      if (entries_[*rit].evictable_) {
        *frame_id = *rit;
        hist_list_.erase(std::next(rit).base());
        victim_found = true;
        break;
      }
    }
  }
  // can't evict one from hist list, try to evict one from cache list
  if (!victim_found && !cache_list_.empty()) {
    // find first evictable frame
    for (auto rit = cache_list_.rbegin(); rit != cache_list_.rend(); ++rit) {
      if (entries_[*rit].evictable_) {
        *frame_id = *rit;
        cache_list_.erase(std::next(rit).base());
        victim_found = true;
        break;
      }
    }
  }
  if (victim_found) {
    entries_.erase(*frame_id);
    --curr_size_;
    return true;
  }
  return false;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);
  // for new frames, default hit count is 0 (see default init for FrameEntry)
  if (frame_id > static_cast<int>(replacer_size_)) {
    throw std::invalid_argument(std::string("Invalid frame_id ") + std::to_string(frame_id));
  }
  size_t new_count = ++entries_[frame_id].hit_count_;

  if (new_count == 1) {  // new frame
    // LOG_INFO("id: NEW FRAME", frame_id);
    ++curr_size_;
    hist_list_.emplace_front(frame_id);
    entries_[frame_id].pos_ = hist_list_.begin();
  } else {                  // existing frame
    if (new_count == k_) {  // reach k-hit, move from hist list to the front of cache list
      // LOG_INFO("id: MOVE FROM HIST TO CACHE", frame_id);
      hist_list_.erase(entries_[frame_id].pos_);
      cache_list_.emplace_front(frame_id);
      entries_[frame_id].pos_ = cache_list_.begin();
    } else if (new_count > k_) {  // move to the front of cache list (LRU)
      cache_list_.erase(entries_[frame_id].pos_);
      cache_list_.emplace_front(frame_id);
      entries_[frame_id].pos_ = cache_list_.begin();
    }

    // new_count < k_, keep in hist list.
    // do not move because we want to evict earliest coming frame (FIFO)
  }

  // LOG_INFO("RECORD: %d ", frame.id);
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::scoped_lock<std::mutex> lock(latch_);
  if (frame_id > static_cast<int>(replacer_size_)) {
    throw std::invalid_argument(std::string("Invalid frame_id ") + std::to_string(frame_id));
  }
  if (entries_.find(frame_id) == entries_.end()) {
    return;
  }

  if (set_evictable && !entries_[frame_id].evictable_) {
    ++curr_size_;
  } else if (entries_[frame_id].evictable_ && !set_evictable) {
    --curr_size_;
  }

  entries_[frame_id].evictable_ = set_evictable;
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);
  if (entries_.find(frame_id) == entries_.end()) {
    return;
  }

  if (!entries_[frame_id].evictable_) {
    throw std::logic_error(std::string("Can't remove an invectable frame ") + std::to_string(frame_id));
  }

  if (entries_[frame_id].hit_count_ < k_) {  // in hist list
    hist_list_.erase(entries_[frame_id].pos_);
  } else {  // in cache list
    cache_list_.erase(entries_[frame_id].pos_);
  }

  --curr_size_;

  entries_.erase(frame_id);

  // PrintList();
}

auto LRUKReplacer::Size() -> size_t {
  std::scoped_lock<std::mutex> lock(latch_);
  return curr_size_;
}

}  // namespace bustub
