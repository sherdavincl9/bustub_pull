//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// p0_trie.h
//
// Identification: src/include/primer/p0_trie.h
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "common/exception.h"
#include "common/rwlatch.h"

namespace bustub {

/**
 * TrieNode is a generic container for any node in Trie.
 */
class TrieNode {
 public:
  /**
   * TODO(P0): Add implementation
   *
   * @brief Construct a new Trie Node object with the given key char.
   * is_end_ flag should be initialized to false in this constructor.
   *
   * @param key_char Key character of this trie node
   */
  explicit TrieNode(char key_char) { this->key_char_ = key_char; }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Move constructor for trie node object. The unique pointers stored
   * in children_ should be moved from other_trie_node to new trie node.
   *
   * @param other_trie_node Old trie node.
   */
  TrieNode(TrieNode &&other_trie_node) noexcept
      : key_char_(other_trie_node.key_char_),
        is_end_(other_trie_node.is_end_),
        children_(std::move(other_trie_node.children_)) {}
  // completed
  // 移动赋值运算符
  TrieNode &operator=(TrieNode &&other) noexcept {
    if (this != &other) {
      key_char_ = other.key_char_;
      is_end_ = other.is_end_;
      children_ = std::move(other.children_);
    }
    return *this;
  }
  /**
   * @brief Destroy the TrieNode object.
   */
  virtual ~TrieNode() = default;

  /**
   * TODO(P0): Add implementation
   *
   * @brief Whether this trie node has a child node with specified key char.
   *
   * @param key_char Key char of child node.
   * @return True if this trie node has a child with given key, false otherwise.
   */
  bool HasChild(char key_char) const {
    if (children_.empty()) {
      return false;
    }
    return children_.find(key_char) != children_.end();
  }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Whether this trie node has any children at all. This is useful
   * when implementing 'Remove' functionality.
   *
   * @return True if this trie node has any child node, false if it has no child node.
   */
  bool HasChildren() const { return !children_.empty(); }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Whether this trie node is the ending character of a key string.
   *
   * @return True if is_end_ flag is true, false if is_end_ is false.
   */
  bool IsEndNode() const { return is_end_; }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Return key char of this trie node.
   *
   * @return key_char_ of this trie node.
   */
  char GetKeyChar() const { return key_char_; }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Insert a child node for this trie node into children_ map, given the key char and
   * unique_ptr of the child node. If specified key_char already exists in children_,
   * return nullptr. If parameter `child`'s key char is different than parameter
   * `key_char`, return nullptr.
   *
   * Note that parameter `child` is rvalue and should be moved when it is
   * inserted into children_map.
   *在C++中，右值引用是一种特殊类型的引用，它可以绑定到一个临时对象（也就是右值）。
   *当我们有一个即将被销毁的对象（比如一个临时对象或者一个没有被使用的对象）时，我们可以使用右值引用来获取这个对象的所有权，
   *而不是复制它。这就是为什么我们说，如果一个参数是右值引用，那么它引用的是一个即将被销毁的对象。
   *左值引用则是变量别名，操作的还是原对象。
   * The return value is a pointer to unique_ptr because pointer to unique_ptr can access the
   * underlying data without taking ownership of the unique_ptr. Further, we can set the return
   * value to nullptr when error occurs.
   *关于返回值，InsertChildNode函数返回一个指向unique_ptr的指针，这样做的好处是，
   *返回的指针可以访问unique_ptr所拥有的对象，但并不拥有unique_ptr。这意味着，当你使用返回的指针时，
   *你不会意外地删除unique_ptr所拥有的对象。此外，如果插入操作失败，函数可以返回nullptr，这是一种表示错误的常见方式。
   * @param key Key of child node
   * @param child Unique pointer created for the child node. This should be added to children_ map.
   * @return Pointer to unique_ptr of the inserted child node. If insertion fails, return nullptr.
   */
  std::unique_ptr<TrieNode> *InsertChildNode(char key_char, std::unique_ptr<TrieNode> &&child) {
    if (HasChild(key_char) || child->GetKeyChar() != key_char) {
      return nullptr;
    }
    auto pair = children_.emplace(key_char, std::move(child));
    return &(pair.first->second);
  }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Get the child node given its key char. If child node for given key char does
   * not exist, return nullptr.
   *
   * @param key Key of child node
   * @return Pointer to unique_ptr of the child node, nullptr if child
   *         node does not exist.
   */
  std::unique_ptr<TrieNode> *GetChildNode(char key_char) {
    auto it = children_.find(key_char);
    if (it != children_.end()) {
      return &(it->second);
    }
    return nullptr;
  }  // completed
  /*
   * TODO(P0): Add implementation
   *
   * @brief Remove child node from children_ map.
   * If key_char does not exist in children_, return immediately.
   *
   * @param key_char Key char of child node to be removed
   */
  void RemoveChildNode(char key_char) { children_.erase(key_char); }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Set the is_end_ flag to true or false.
   *
   * @param is_end Whether this trie node is ending char of a key string
   */
  void SetEndNode(bool is_end) { this->is_end_ = is_end; }  // completed

 protected:
  /** Key character of this trie node */
  char key_char_;
  /** whether this node marks the end of a key */
  bool is_end_{false};
  /** A map of all child nodes of this trie node, which can be accessed by each
   * child node's key char. */
  std::unordered_map<char, std::unique_ptr<TrieNode>> children_;
};

/**
 * TrieNodeWithValue is a node that marks the ending of a key, and it can
 * hold a value of any type T.
 */
template <typename T>
class TrieNodeWithValue : public TrieNode {
 private:
  /* Value held by this trie node. */
  T value_;

 public:
  /**
   * TODO(P0): Add implementation
   *
   * @brief Construct a new TrieNodeWithValue object from a TrieNode object and specify its value.
   * This is used when a non-terminal TrieNode is converted to terminal TrieNodeWithValue.
   *
   * The children_ map of TrieNode should be moved to the new TrieNodeWithValue object.
   * Since it contains unique pointers, the first parameter is a rvalue reference.
   *
   * You should:
   * 1) invoke TrieNode's move constructor to move data from TrieNode to
   * TrieNodeWithValue.
   * 2) set value_ member variable of this node to parameter `value`.
   * 3) set is_end_ to true
   *
   * @param trieNode TrieNode whose data is to be moved to TrieNodeWithValue
   * @param value
   *这是TrieNodeWithValue类的构造函数，它接受一个TrieNode的右值引用和一个值作为参数。
    在这个构造函数中，TrieNode(std::move(trieNode))是调用基类TrieNode的移动构造函数，
    将trieNode的资源移动到新创建的TrieNodeWithValue对象中。这并不意味着TrieNodeWithValue类有一个TrieNode的成员，
    而是表示TrieNodeWithValue类是从TrieNode类派生的，所以它包含了TrieNode类的所有成员和方法。
    关于noexcept，移动构造函数和移动赋值操作通常都应该被声明为noexcept。
    这是因为，如果这些操作可能抛出异常，那么一些标准库函数（比如std::vector::resize）可能无法正确地工作。
    然而，如果你确定你的移动构造函数和移动赋值操作不会抛出异常，那么你可以省略noexcept关键字。
    在你的代码中，由于你的移动构造函数只是简单地移动了一些资源，所以它应该是不会抛出异常的。
   */
  TrieNodeWithValue(TrieNode &&trieNode, T value) : TrieNode(std::move(trieNode)), value_(value) {
    SetEndNode(true);
  }  // completed

  /**
   * TODO(P0): Add implementation
   *
   * @brief Construct a new TrieNodeWithValue. This is used when a new terminal node is constructed.
   *
   * You should:
   * 1) Invoke the constructor for TrieNode with the given key_char.
   * 2) Set value_ for this node.
   * 3) set is_end_ to true.
   *
   * @param key_char Key char of this node
   * @param value Value of this node
   */
  TrieNodeWithValue(char key_char, T value) : TrieNode(key_char), value_(value) { SetEndNode(true); }  // completed
  /**
   * @brief Destroy the Trie Node With Value object
   */
  ~TrieNodeWithValue() override = default;

  /**
   * @brief Get the stored value_.
   *
   * @return Value of type T stored in this node
   */
  T GetValue() const { return value_; }
};

/**
 * Trie is a concurrent key-value store. Each key is a string and its corresponding
 * value can be any type.
 */
class Trie {
 private:
  /* Root node of the trie */
  std::unique_ptr<TrieNode> root_;
  /* Read-write lock for the trie */
  ReaderWriterLatch latch_;

 public:
  /**
   * TODO(P0): Add implementation
   *
   * @brief Construct a new Trie object. Initialize the root node with '\0'
   * character.
   */
  Trie() : root_(std::make_unique<TrieNode>('\0')) {}
  // RAII to manage the readlock and writelock
  class WLockGuard {
   public:
    explicit WLockGuard(ReaderWriterLatch &latch) : latch_(latch) { latch_.WLock(); }
    ~WLockGuard() { latch_.WUnlock(); }

   private:
    ReaderWriterLatch &latch_;
  };
  class RLockGuard {
   public:
    explicit RLockGuard(ReaderWriterLatch &latch) : latch_(latch) { latch_.RLock(); }
    ~RLockGuard() { latch_.RUnlock(); }

   private:
    ReaderWriterLatch &latch_;
  };
  // RAII has completed
  /**
   * TODO(P0): Add implementation
   *
   * @brief Insert key-value pair into the trie.
   *
   * If the key is an empty string, return false immediately.
   *
   * If the key already exists, return false. Duplicated keys are not allowed and
   * you should never overwrite value of an existing key.
   *
   * When you reach the ending character of a key:
   * 1. If TrieNode with this ending character does not exist, create new TrieNodeWithValue
   * and add it to parent node's children_ map.
   * 2. If the terminal node is a TrieNode, then convert it into TrieNodeWithValue by
   * invoking the appropriate constructor.
   * 3. If it is already a TrieNodeWithValue,
   * then insertion fails and returns false. Do not overwrite existing data with new data.
   *
   * You can quickly check whether a TrieNode pointer holds TrieNode or TrieNodeWithValue
   * by checking the is_end_ flag. If is_end_ == false, then it points to TrieNode. If
   * is_end_ == true, it points to TrieNodeWithValue.
   *
   * @param key Key used to traverse the trie and find the correct node
   * @param value Value to be inserted
   * @return True if insertion succeeds, false if the key already exists
   */
  template <typename T>
  bool Insert(const std::string &key, T value) {
    WLockGuard guard(latch_);
    if (key.empty()) {
      return false;
    }
    std::unique_ptr<TrieNode> *node = &root_;
    for (char ch : key) {
      if (!node->get()->HasChild(ch)) {
        node->get()->InsertChildNode(ch, std::make_unique<TrieNode>(ch));
      }
      node = node->get()->GetChildNode(ch);
    }
    if ((*node)->IsEndNode()) {
      // The key already exists in the trie.
      return false;
    }
    // The key does not exist, insert the value.
    *node = std::make_unique<TrieNodeWithValue<T>>(std::move(*(*node)), value);
    return true;
  }

  /**
   * TODO(P0): Add implementation
   *
   * @brief Remove key value pair from the trie.
   * This function should also remove nodes that are no longer part of another
   * key. If key is empty or not found, return false.
   *
   * You should:
   * 1) Find the terminal node for the given key.
   * 2) If this terminal node does not have any children, remove it from its
   * parent's children_ map.
   * 3) Recursively remove nodes that have no children and are not terminal node
   * of another key.
   *
   * @param key Key used to traverse the trie and find the correct node
   * @return True if the key exists and is removed, false otherwise
   */
  bool Remove(const std::string &key) {
    WLockGuard guard(latch_);
    if (key.empty()) {
      return false;
    }
    std::vector<std::unique_ptr<TrieNode> *> storage;
    std::unique_ptr<TrieNode> *node = &root_;
    for (char ch : key) {
      storage.emplace_back(node);
      std::unique_ptr<TrieNode> *next = node->get()->GetChildNode(ch);
      if (next == nullptr) {
        return false;
      }
      node = next;
    }
    if (node->get()->HasChildren()) {
      // node = node->get()->GetChildNode(key[key.size()-1]);
      node->get()->SetEndNode(false);
    } else {
      for (int i = storage.size() - 1; i >= 0; i--) {
        std::unique_ptr<TrieNode> *pre = storage[i];
        if ((i < static_cast<int>(key.size() - 1)) && (node->get()->IsEndNode() || node->get()->HasChildren())) {
          break;
        }
        pre->get()->RemoveChildNode(key[i]);
        node = pre;
      }
    }
    return true;
  }
  /**
   * TODO(P0): Add implementation
   *
   * @brief Get the corresponding value of type T given its key.
   * If key is empty, set success to false.
   * If key does not exist in trie, set success to false.
   * If the given type T is not the same as the value type stored in TrieNodeWithValue
   * (ie. GetValue<int> is called but terminal node holds std::string),
   * set success to false.
   *
   * To check whether the two types are the same, dynamic_cast
   * the terminal TrieNode to TrieNodeWithValue<T>. If the casted result
   * is not nullptr, then type T is the correct type.
   *
   * @param key Key used to traverse the trie and find the correct node
   * @param success Whether GetValue is successful or not
   * @return Value of type T if type matches
   */
  template <typename T>
  T GetValue(const std::string &key, bool *success) {
    RLockGuard guard(latch_);
    *success = false;
    if (key.empty()) {
      return T();
    }
    auto *node = root_.get();
    for (char ch : key) {
      if (!node->HasChild(ch)) {
        return T();
      }
      node = node->GetChildNode(ch)->get();
    }
    if (!node->IsEndNode()) {
      return T();
    }
    const auto *value_node = dynamic_cast<const TrieNodeWithValue<T> *>(node);
    if (!value_node) {
      return T();
    }
    *success = true;
    return value_node->GetValue();
  }
};
}  // namespace bustub
